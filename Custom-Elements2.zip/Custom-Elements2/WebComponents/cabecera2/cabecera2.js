 class cabeceraNueva extends HTMLElement{
    constructor(){
        super()
    }

    connectedCallback(){
        
         fetch('WebComponents/cabecera2/index.html')
        .then(response => response.text())
        .then(html => {
          this.innerHTML = html;
        });
    }
}
window.customElements.define('cabecera-nueva', cabeceraNueva)
