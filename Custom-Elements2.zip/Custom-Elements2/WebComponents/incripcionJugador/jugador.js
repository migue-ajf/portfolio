class jugador extends HTMLElement{
    
    
    constructor(nombre, dorsal, posicion, caracteristicas){
        super()
        this.nombre = nombre
        this.dorsal = dorsal
        this.posicion = posicion
        this.caracteristicas = caracteristicas
    }
    connectedCallback(){
        

        const shadow = this.attachShadow({mode: 'open'})
         fetch('WebComponents/incripcionJugador/index.html')
        .then(response => response.text())
        .then(html => {
        shadow.innerHTML = html;
        
        });
    }

    ensenyardatos(){
        console.log(`${this.nombre}, ${this.dorsal}, ${this.posicion},${this.caracteristicas}`)
       
    }

   
}
function cogerDatos() {
    var nombre=document.getElementById("names").value
    var dorsal=document.getElementById("dorsal").value
    var posicion=document.getElementById("posicion").value
    var caracteristicas = document.getElementById("caracteristicas").value
   }
window.customElements.define('formulario-jugador', jugador)